public class Test {

    public static void main(String[] args) {

	TestFrequencyTable.main(args);
	TestDistance.main(args);
	TestLinkedList.main(args);
	TestLinkedStack.main(args);
	
    }

}
