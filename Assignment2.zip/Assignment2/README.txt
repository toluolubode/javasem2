Student 1: Toluwanimi Olubode (8696226). Section B
Student 2: Toluwani Ogunsanya (8677256). Section C

Assignment Description:
Assignment 2
